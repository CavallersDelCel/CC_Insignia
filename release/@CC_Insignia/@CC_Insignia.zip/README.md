# CC_Insignia
Official flags, patches and markers of Cavallers del Cel community and 1RA group.

# AUTHORS

- Moska
- Atunero
