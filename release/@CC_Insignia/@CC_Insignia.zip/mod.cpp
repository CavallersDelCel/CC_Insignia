name = "CC Insignia";
author = "Cavallers del Cel";
picture = "logo_ccescut_ca.paa";
actionName = "Portal web";
action = "http://www.cavallersdelcel.cat";
description = "Marcadors, banderes i pegats del grup 1RA de la Comunitat Catalana de Simulació Cavallers del Cel";
